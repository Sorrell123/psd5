/*
$(document).ready(function(){
	$(".link").hover(function(){
		$(this).siblings().find(".arrow").css("color", "white");
	}, function(){
		$(this).siblings().find(".arrow").css("color", "#5f12a6");
	});
});
*/